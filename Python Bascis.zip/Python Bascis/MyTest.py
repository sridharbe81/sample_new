print ("Hello World")

list = [1,"A",2,3,"b"]
list[0] = 0
print (list)

a = 10
b = 21
c = a+b
print(sum(a,b))







