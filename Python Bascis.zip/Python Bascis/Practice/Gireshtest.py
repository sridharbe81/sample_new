list = [1,2,3,4]
#tup = (91,2,3,)
#tup[1]= 3
list [1] = 4
str = 'gireesh  babu bayyavallu'
q =  str.split()
print (q)
print (" ".join(q))

dic = {4:'ram',2:'lakshman', 1:'sita', 2:'hanuman'}
print (dic.keys())
print (dic.items())
for i, j in dic.items():
    print (i,j)
print (dic.sort())