import math
def radius(r):
    area = 3.14*r*r
    return area
print("Area of Circle:",radius(4))


a=2
b=4
c= a**2 + b**2
print(c)
print("The Hypo:", c**(1.0/2))

x=2+1
print(str(x)*11)


my_dict= {"name":"Vivek", "DU" : "Nat", "sap":51388990}
print(my_dict.keys())

for x in range (1,6):
    for y in range (1, x+1):
        print (x, ' ', y)

z=10
print(z>>2)

