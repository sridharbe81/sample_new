# Create a program to count by prime numbers. Ask the user to input a number, then print each prime number up to that number

number = 20
# for x in range(2,number+1):
#     for y in range(2,x):
#         if x%2 ==0:
#             break
#     else:
#         print(x)

'''Instruct the user to pick an arbitrary number from 1 to 100 and proceed to guess it correctly within seven tries.
 After each guess, the user must tell whether their number is higher than, lower than, or equal to your guess.'''

# input = input("Enter the number" )
# usernumber = int(input)
# my_number = 50
# if (usernumber<=my_number):
#     print ("The number is lower than my number" + str(my_number))
# elif (usernumber >= my_number):
#     print("The number is greater than my number" + str(my_number))
# elif (usernumber == my_number) :
#     print("The number is equal to my number" + str(my_number))

#	Print all the characters in sentence "The continue statement is used in a while or for loop"
for i in 'python':
    if i== "t":
        continue
    print(i)

x=input('Enter a passkeyid: ')
while x != 10:
    print(x),
    x=input('Enter a passkeyid: ')
key=input("Press key...")




