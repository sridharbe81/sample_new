import re

# var1 = "My first words"
# p = re.compile('[0-9]')
# print p.match(var1)


# var1 = "My first words"
#
# var2 = re.match(r[a-z])
# print (var2)

# var = re.split(r'\s*','here are few words')
# #print (var)
# for i in var:
#     print (i)

# my_dic = {'name': 'sridhar', 'age': '35', 'sex': 'male'}
# for key, val in my_dic.iteritems():
#    print key, val


p = re.compile('\d+')

n = p.match('sridhar is my name sridhar is a person')
print (n)
b = p.findall('sridhar is my name sridhar is a person 25 how 15')

print (b)
#print (n.span())


#print(re.split(r'\s*','here are few words'))
#
#
#print(re.split(r'[a-f]','adadfsdshshfsshshh'))
# #
# value1 = "PRA BHU"
# output1 = re.sub("\s", "", value1)
# print("output1:", output1)
# #
# value2 = "PRABHUSP121"
# output2 = re.sub("[0-9]", "", value2)
# print("output2:", output2)
# #
# value3 = "PRABHUSP121"
# output3 = re.sub("[A-Z]", "", value3)
# print("output3:", output3)
# #
# value5 = "PRABHU.SP-121"
# output5 = re.sub("\W", "", value5)
# print("output5:", output5)
# #
# value6 = "PRABHU.SP-121"
# output6 = re.sub("\w", "", value6)
# print("output6:", output6)
#
# value7 = "PRABHUsp121"
# output7 = re.sub("\d", "", value7)
# print("output7:", output7)
# #
# value8 = "PRABHUsp121"
# output8 = re.sub("\D", "", value8)
# print("output8:", output8)
#
# # search and replace
# list = ['fa0/1','fa0/2','fa0/3']
# for i in list:
#     i=re.sub("fa",'gig', i, re.IGNORECASE)
#     print (i)
#
# # write a content in a file and replace the string
# file_name = 'example.txt'
# with open(file_name,'w') as write_file:
#     lines = ['fast ethernet0/1\n',
#               'gigabit ethernet0/1\n']
#     write_file.writelines(lines)
#
# with open(file_name, 'r') as read_file:
#     for lines in read_file.readlines():
#         print (lines.rstrip())
#         change_lines = lines.replace('fast', 'gigabit')
#         print (change_lines)
#
# value9 = "dog cat dog"
# match = re.match(r'dog', value9)
# print("output9:", match.group())
#
# value10 = "dog cat dog cat"
# match = re.search(r'cat', value10)
# print("output10:", match.group())


# value11 = "PRABHUSP:121"
# matchobj = re.search(r'([A-Z]+)\:([0-9]+)', value11)
# #matchobj1 = re.search(r'(.*)\:(.*)', value11)
# if matchobj:
#     print(matchobj.group(1))
#     print(matchobj.group(2))
#
#
# value11="prabsund@cisco.com"
# matchobj1=re.search(r'(.*)\@',value11)
# if matchobj1:
# 	print(matchobj1.group(1))
# 	#print(matchobj1.group(2))
#
# print(re.sub(r'[a-e]','8','vivekananth palanivel'))
# print(re.findall(r'\d.*','vivek 162 sowmya nagar 10th stree exten'))