import os

os.chdir('C:\Vivek\personal\Cisco Books & CBT Nugget\CCNA Videos\Route_642-902\nugget')
print(os.listdir())